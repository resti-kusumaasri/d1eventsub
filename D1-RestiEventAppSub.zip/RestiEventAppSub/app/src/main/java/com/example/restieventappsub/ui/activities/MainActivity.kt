@file:Suppress("DEPRECATION")

package com.example.restieventappsub.ui.activities

import android.content.IntentFilter
import android.net.ConnectivityManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.eventapp.R
import com.example.eventapp.databinding.ActivityMainBinding
import com.example.restieventappsub.ui.dialogs.NetDialog
import com.example.restieventappsub.utils.NetUtills
import com.example.restieventappsub.utils.NetUtills.isNetworkAvailable
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var networkChangeReceiver: NetUtills.NetworkChangeReceiver
    private var networkDialog: NetDialog? = null
    private var dataRefreshListener: NetworkChangeListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        networkDialog = NetDialog(this)
        setupNetworkChangeReceiver()

        val bottomNav: BottomNavigationView = binding.bottomNav
        val navController = findNavController(R.id.nav_host_fragment_container)

        val appBarConfiguration = AppBarConfiguration(setOf(R.id.navigation_home, R.id.navigation_upcoming, R.id.navigation_done))
        setupActionBarWithNavController(navController, appBarConfiguration)
        bottomNav.setupWithNavController(navController)

    }

    private fun setupNetworkChangeReceiver() {
        networkChangeReceiver = NetUtills.NetworkChangeReceiver { isConnected ->
            if (!isConnected) {
                networkDialog?.showNoInternetDialog {
                    if (isNetworkAvailable(this)) {
                        networkDialog?.dismissDialog()
                        dataRefreshListener?.onNetworkChanged()
                    } else {
                        Toast.makeText(this, "No Internet Connection!", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                networkDialog?.dismissDialog()
                dataRefreshListener?.onNetworkChanged()
            }
        }
        val filter = IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
        registerReceiver(networkChangeReceiver, filter)
    }


    override fun onDestroy() {
        super.onDestroy()
        networkDialog?.dismissDialog()
    }

    fun setOnDataRefreshListener(listener: NetworkChangeListener) {
        dataRefreshListener = listener
    }

    interface NetworkChangeListener {
        fun onNetworkChanged()
    }

}