package com.example.restieventappsub.ui.fragment

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.eventapp.databinding.FragmentHomeBinding
import com.example.restieventappsub.ui.activities.MainActivity
import com.example.restieventappsub.ui.adapters.HorizonAdapter
import com.example.restieventappsub.ui.adapters.VerticAdapter
import com.example.restieventappsub.viewmodels.MainViewModel

class HomeFragment : Fragment(), MainActivity.NetworkChangeListener {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by viewModels()
    private lateinit var verticAdapter: VerticAdapter
    private lateinit var horizonAdapter: HorizonAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupAllRecyclerView()
        setupAllNetworkData()
    }

    private fun setupAllRecyclerView() {
        // Upcoming events
        horizonAdapter = HorizonAdapter(true)
        binding.upcomingRecyclerView.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = horizonAdapter
        }
        // Finished Events
        verticAdapter = VerticAdapter()
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = verticAdapter
        }
    }

    private fun setupAllNetworkData() {
        viewModel.listUpcoming.observe(viewLifecycleOwner) { listEvents ->
            listEvents?.let {
                // Stop shimmer and submit the data
                horizonAdapter.setLoadingState(false)
                horizonAdapter.submitList(it.take(5))
            }
        }
        viewModel.listDone.observe(viewLifecycleOwner) { listEvents ->
            listEvents?.let {
                // Stop shimmer and submit the data
                verticAdapter.setLoadingState(false)
                verticAdapter.submitList(it.take(5))
            }
        }
        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            // Toggle shimmer effect
//            upcomingAdapter.setLoadingState(isLoading)
//            horizontalAdapter.setLoadingState(isLoading)
        }
//        viewModel.isEmpty.observe(viewLifecycleOwner, Observer { isEmpty ->
//            horizontalAdapter.setLoadingState(isEmpty)
//        })
    }

    override fun onNetworkChanged() {
//        horizontalAdapter.setLoadingState(true)
        viewModel.refreshData()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            (context as? MainActivity)?.setOnDataRefreshListener(this)
        } catch (e: ClassCastException) {
            throw ClassCastException("$context must implement OnDataRefreshListener")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}